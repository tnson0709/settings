// Tab điều hướng
const tabs = {
  login: document.getElementById('tabLogin'),
  register: document.getElementById('tabRegister'),
  profile: document.getElementById('tabProfile'),
};
const forms = {
  login: document.getElementById('formLogin'),
  register: document.getElementById('formRegister'),
  profile: document.getElementById('formProfile'),
};
function activateTab(tabName) {
  Object.keys(tabs).forEach(key => {
    tabs[key].classList.toggle('active', key === tabName);
    forms[key].classList.toggle('active', key === tabName);
  });
}
tabs.login.onclick = () => activateTab('login');
tabs.register.onclick = () => activateTab('register');
tabs.profile.onclick = () => {
  if (!currentUser) {
    alert('Vui lòng đăng nhập để truy cập hồ sơ.');
    activateTab('login');
  } else {
    loadProfileForm();
    activateTab('profile');
  }
};
// IndexedDB Setup ----------------------
const DB_NAME = 'UserAuthDB';
const DB_VERSION = 1;
const STORE_NAME = 'users';
let db;
let currentUser = null; // user object {name,email,role,password,...}
let currentTokens = null; // {accessToken, refreshToken}
function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject('Không thể mở IndexedDB.');
    request.onsuccess = (e) => {
      db = e.target.result;
      resolve(db);
    };
    request.onupgradeneeded = (e) => {
      db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'email' });
      }
    };
  });
}
function saveUserToDB(user) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readwrite');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.put(user);
    request.onsuccess = () => resolve();
    request.onerror = () => reject('Lỗi khi lưu user vào DB');
  });
}
function getUserFromDB(email) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, 'readonly');
    const store = transaction.objectStore(STORE_NAME);
    const request = store.get(email);
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject('Không tìm thấy user');
  });
}
// Authentication & Token Simulation -----------
function generateToken(email) {
  return btoa(email + ':' + Date.now());
}
function generateTokens(email) {
  return {
    accessToken: 'access-' + generateToken(email),
    refreshToken: 'refresh-' + generateToken(email)
  };
}
// Fake OTP check (123456 là mã xác thực hợp lệ)
function verifyOTP(code) {
  return code === '123456';
}
// Đăng ký user mới
async function registerUser(name, email, password, role) {
  const exists = await getUserFromDB(email);
  if (exists) throw new Error('Email đã được đăng ký!');
  const user = {name, email, password, role};
  await saveUserToDB(user);
}
// Đăng nhập user
async function loginUser(email, password, otp) {
  const user = await getUserFromDB(email);
  if (!user) throw new Error('Email không tồn tại.');
  if (user.password !== password) throw new Error('Sai mật khẩu.');
  if (!verifyOTP(otp)) throw new Error('Mã OTP không hợp lệ.');
  const tokens = generateTokens(email);
  return {user, tokens};
}
// Google OAuth mô phỏng
async function googleLogin() {
  // Tạo user mô phỏng
  const email = 'googleuser@example.com';
  let user = await getUserFromDB(email);
  if (!user) {
    user = {name: 'Người dùng Google', email, password: '', role: 'staff'};
    await saveUserToDB(user);
  }
  const tokens = generateTokens(email);
  return {user, tokens};
}
// Đồng bộ user hiện tại lên server (giả lập API)
async function syncToServer(user, tokens) {
  const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({user, tokens}),
  });
  if (!response.ok) throw new Error('Đồng bộ thất bại.');
  return await response.json();
}
// --- Form xử lý ---
// Đăng ký
document.getElementById('formRegister').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('regName').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value.trim();
  const role = document.getElementById('regRole').value;
  if (!name || !email || !password || !role) {
    alert('Vui lòng điền đầy đủ thông tin!');
    return;
  }
  try {
    await registerUser(name, email, password, role);
    alert('Đăng ký thành công! Vui lòng đăng nhập.');
    // Reset form
    e.target.reset();
    activateTab('login');
  } catch (error) {
    alert(error.message);
  }
});
// Đăng nhập
document.getElementById('formLogin').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value.trim();
  const password = document.getElementById('loginPassword').value.trim();
  const otp = document.getElementById('loginOTP').value.trim();
  if (!email || !password || !otp) {
    alert('Vui lòng nhập đủ thông tin!');
    return;
  }
  try {
    const {user, tokens} = await loginUser(email, password, otp);
    currentUser = user;
    currentTokens = tokens;
    alert(`Xin chào ${user.name}! Bạn đã đăng nhập với quyền ${user.role}.\nAccess Token: ${tokens.accessToken}\nRefresh Token: ${tokens.refreshToken}`);
    activateTab('profile');
    loadProfileForm();
    // Reset login form
    e.target.reset();
  } catch (error) {
    alert(error.message);
  }
});
// Google đăng nhập nút
document.getElementById('btnGoogleLogin').addEventListener('click', async () => {
  try {
    const {user, tokens} = await googleLogin();
    currentUser = user;
    currentTokens = tokens;
    alert(`Đăng nhập Google thành công!\nXin chào ${user.name}.\nVai trò: ${user.role}`);
    activateTab('profile');
    loadProfileForm();
  } catch (error) {
    alert('Lỗi đăng nhập Google.');
  }
});
// Load dữ liệu user lên form hồ sơ
function loadProfileForm() {
  if (!currentUser) return;
  document.getElementById('profileName').value = currentUser.name;
  document.getElementById('profileEmail').value = currentUser.email;
  document.getElementById('profileRole').value = currentUser.role;
}
// Lưu hồ sơ thay đổi
document.getElementById('btnSaveProfile').addEventListener('click', async () => {
  if (!currentUser) {
    alert('Vui lòng đăng nhập.');
    activateTab('login');
    return;
  }
  const name = document.getElementById('profileName').value.trim();
  if (!name) {
    alert('Họ và tên không được để trống.');
    return;
  }
  currentUser.name = name;
  try {
    await saveUserToDB(currentUser);
    alert('Lưu hồ sơ thành công!');
  } catch {
    alert('Lỗi khi lưu hồ sơ.');
  }
});
// Đồng bộ dữ liệu lên server
document.getElementById('btnSync').addEventListener('click', async () => {
  if (!currentUser ||

 !currentTokens) {
    alert('Vui lòng đăng nhập để đồng bộ.');
    activateTab('login');
    return;
  }
  try {
    await syncToServer(currentUser, currentTokens);
    alert('Đồng bộ thành công lên server!');
  } catch {
    alert('Lỗi đồng bộ lên server!');
  }
});
// Khởi chạy IndexedDB
openDB().then(() => console.log("DB đã sẵn sàng"))
  .catch(console.error);
// Khởi đầu là tab Đăng nhập
activateTab('login');
// Hiển thị thông tin người dùng hiện tại nếu có